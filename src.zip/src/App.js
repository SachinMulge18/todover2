import React from "react";
import ToDo from "./Components/ToDo";
import 'bootstrap/dist/css/bootstrap.min.css'
const App = () => {
  return (
    <>
      <h1 style={{ textAlign: "center" }}>
        Roxiler System
      </h1>
      <ToDo />
    </>
  );
};

export default App;
